from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QMenu, QFileDialog, 
    QMessageBox, QTextEdit, QVBoxLayout, QWidget, QLineEdit, 
    QPushButton, QLabel, QCheckBox, QDialog, QTabWidget, QDockWidget
)
from PyQt6.QtGui import QAction
from PyQt6.QtCore import Qt, QDir

class MainWindow(QMainWindow):
    def __init__(self, preferences):
        super().__init__()

        self.preferences = preferences
        self.setWindowTitle("K.L.A.C. Code Editor")
        self.setGeometry(100, 100, 1200, 800)

        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        file_menu.addAction(self.create_action("Save", self.save_file))
        file_menu.addAction(self.create_action("Export", self.export_file))
        file_menu.addAction(self.create_action("Import", self.import_file))
        file_menu.addAction(self.create_action("Exit", self.close))
        file_menu.addAction(self.create_action("Settings", self.open_settings))

        view_menu = menubar.addMenu("View")
        view_menu.addAction(self.create_action("Show/Hide Source Editor", self.toggle_source_editor))

        # Create tab widget
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Add placeholders
        self.create_placeholders()

    def create_action(self, name, function, checkable=False):
        action = QAction(name, self)
        action.triggered.connect(function)
        action.setCheckable(checkable)
        return action

    def create_placeholders(self):
        # Source Editor
        self.source_editor = QTextEdit()
        self.tabs.addTab(self.source_editor, "Source Editor")

        # HTML/CSS Editor
        self.html_editor = QTextEdit()
        self.tabs.addTab(self.html_editor, "HTML/CSS Editor")

        # Output Viewer
        self.output_viewer = QTextEdit()
        self.output_viewer.setReadOnly(True)
        self.tabs.addTab(self.output_viewer, "Output Viewer")

    def toggle_source_editor(self):
        """Show or hide the Source Editor."""
        if hasattr(self, 'source_editor'):
            self.source_editor.setVisible(not self.source_editor.isVisible())

    def save_file(self):
        # File save logic
        pass

    def export_file(self):
        # File export logic
        pass

    def import_file(self):
        # File import logic
        pass
        
    def open_settings(self):
        """Open the floating settings window."""
        settings_dialog = SettingsDialog(self.preferences)
        settings_dialog.setWindowModality(Qt.WindowModality.NonModal)  # Non-blocking floating window
        settings_dialog.setWindowFlags(settings_dialog.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)  # Always on top
        settings_dialog.show()

class SettingsDialog(QDialog):
    def __init__(self, preferences):
        super().__init__()
        self.preferences = preferences
        self.setWindowTitle("Settings")
        self.setGeometry(300, 300, 400, 300)
        layout = QVBoxLayout()

        # Default save path setting
        layout.addWidget(QLabel("Default Save Path"))
        self.save_path_input = QLineEdit(self.preferences.get('default_save_path', ''))
        layout.addWidget(self.save_path_input)

        # Default export path setting
        layout.addWidget(QLabel("Default Export Path"))
        self.export_path_input = QLineEdit(self.preferences.get('default_export_path', ''))
        layout.addWidget(self.export_path_input)

        # Language setting
        layout.addWidget(QLabel("Language"))
        self.language_input = QLineEdit(self.preferences.get('language', 'English'))
        layout.addWidget(self.language_input)

        # Reopen minimized windows on startup
        self.reopen_windows_checkbox = QCheckBox("Reopen Windows on Startup")
        self.reopen_windows_checkbox.setChecked(self.preferences.get('reopen_windows_on_startup', True))
        layout.addWidget(self.reopen_windows_checkbox)

        # Save button
        save_button = QPushButton("Save")
        save_button.clicked.connect(self.save_settings)
        layout.addWidget(save_button)

        self.setLayout(layout)

    def save_settings(self):
        self.preferences['default_save_path'] = self.save_path_input.text()
        self.preferences['default_export_path'] = self.export_path_input.text()
        self.preferences['language'] = self.language_input.text()
        self.preferences['reopen_windows_on_startup'] = self.reopen_windows_checkbox.isChecked()
        self.accept()