import os
import json
from assistant.llama import manage_llama_model
from PyQt6.QtWidgets import QApplication
from gui import MainWindow

# Path to the preferences file
PREFERENCES_FILE = "preferences.klac"
KLAC_DIRECTORY = os.path.join("data", "klac")
CONFIG_FILE = os.path.join(KLAC_DIRECTORY, "config.klac")

DEFAULT_CONFIG = {
    "model_path": os.path.join(KLAC_DIRECTORY, "Models"),
    "training_data_path": os.path.join(KLAC_DIRECTORY, "training_data"),
    "max_model_size_mb": 300,
    "assistant_enabled": True
}

# Functions for configuration
def ensure_klac_directory():
    """Ensure that the data/klac directory exists."""
    if not os.path.exists(KLAC_DIRECTORY):
        os.makedirs(KLAC_DIRECTORY)
        print(f"Created directory: {KLAC_DIRECTORY}")

def create_default_config():
    """Create default config.klac file if it doesn't exist."""
    if not os.path.exists(CONFIG_FILE):
        print(f"{CONFIG_FILE} not found. Creating default config.")
        with open(CONFIG_FILE, "w") as config_file:
            json.dump(DEFAULT_CONFIG, config_file, indent=4)
        print(f"Default config.klac created at {CONFIG_FILE}.")
    else:
        print(f"Config file found at {CONFIG_FILE}. Skipping creation.")

def load_config():
    """Load the config.klac file."""
    try:
        with open(CONFIG_FILE, "r") as config_file:
            return json.load(config_file)
    except FileNotFoundError:
        print(f"{CONFIG_FILE} not found. Loading default configuration.")
        return DEFAULT_CONFIG

def save_config(config):
    """Save the current configuration to the config.klac file."""
    with open(CONFIG_FILE, "w") as config_file:
        json.dump(config, config_file, indent=4)
    print(f"Configuration saved to {CONFIG_FILE}.")

# Functions for preferences
def load_preferences():
    """Load user preferences from a .klac file."""
    try:
        with open(PREFERENCES_FILE, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {
            "assistant_enabled": False,
            "max_model_size_mb": 500,
            "allow_custom_training": False,
        }

def save_preferences(preferences):
    """Save user preferences to a .klac file."""
    with open(PREFERENCES_FILE, "w") as file:
        json.dump(preferences, file, indent=4)

if __name__ == '__main__':
    app = QApplication([])

    # Ensure the directory and config file exist
    ensure_klac_directory()
    create_default_config()

    # Load configuration and preferences
    config = load_config()
    preferences = load_preferences()

    # Initialize the main window with preferences
    window = MainWindow(preferences)

    # Load assistant model if enabled
    if preferences.get("assistant_enabled"):
        manage_llama_model()

    window.show()
    app.exec()
